export enum Exchange {
    CHAPTER = 'chapter',
    USER = 'user',
    INVOICE = 'invoice',
    SERVICE_PACKAGE = 'servicePackage',
    SERVICE_PACKAGE_TRANSACTION = 'servicePackageTransaction'
}