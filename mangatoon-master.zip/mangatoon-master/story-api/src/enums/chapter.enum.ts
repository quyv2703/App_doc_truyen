export enum ChapterStatus {
    RELEASED = 0,
    DELETED = 1
}