export enum StoryStatus {
    UNPUBLISHED = 0,
    IN_PROGRESS = 1,
    SUSPENDED = 2,
    FINISHED = 3,
    DELETED = 4
}