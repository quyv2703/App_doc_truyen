export enum TransformerGroup {
    INCLUDE = 'include',
    EXCLUDE = 'exclude'
}