export enum TransformerGroup {
    INCLUDE = 'include',
    EXCLUDE = 'exclude',
    EXCLUDE_PAGE_LIMIT = 'exclude_page_limit'
}