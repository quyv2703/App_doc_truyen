export class ChapterDTO {
    id: number
    order: number
    name: string
    status: number
    createdAt: Date
    updatedAt: Date
    storyId: number
}