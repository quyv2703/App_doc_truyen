const encoded = require("./encode");
const decode = require("./decode");
module.exports = {
  encoded,
  decode,
};
