 
const sendConsumerCreateNewAccount = require("./consumer");

sendConsumerCreateNewAccount();
 

