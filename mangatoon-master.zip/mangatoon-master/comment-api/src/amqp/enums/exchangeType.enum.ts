export enum ExchangeType {
    FANOUT = 'fanout',
    DIRECT = 'direct',
    TOPIC = 'topic'
}