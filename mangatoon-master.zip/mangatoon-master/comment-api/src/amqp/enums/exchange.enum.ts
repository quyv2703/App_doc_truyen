export enum Exchange {
    CHAPTER = 'chapter',
    USER = 'user'
}