export enum TransformerGroup {
    EXCLUDE = 'exclude'
}