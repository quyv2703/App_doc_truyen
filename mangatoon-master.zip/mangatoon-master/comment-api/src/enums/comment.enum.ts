export enum CommentStatus {
    CREATED = 0,
    DELETED = 1
}