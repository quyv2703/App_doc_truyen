export enum CommentInteractionType {
    LIKE = 0,
    DISLIKE = 1
}