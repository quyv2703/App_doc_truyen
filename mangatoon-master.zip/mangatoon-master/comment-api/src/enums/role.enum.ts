export enum Role {
    GUEST = 'guest',
    ADMIN = 'admin',
    USER = 'user'
}